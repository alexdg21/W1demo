﻿using System;

namespace W1_Demo
{
    class Program
    {
        static void Main(string[] args)
        {
            var qty = 120.2;
            var price = 3.29;

            var amount = Calculate(qty, price);
            Console.WriteLine("The amount owened = " + amount);
        }

        private static double Calculate(double qty, double price)
        {
            return qty * price;
        }
       
    }
}
